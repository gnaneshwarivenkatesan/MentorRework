import { Component, OnInit, Input } from '@angular/core';
import { Mentor } from '../mentor';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentor-landingpage',
  templateUrl: './mentor-landingpage.component.html',
  styleUrls: ['./mentor-landingpage.component.css']
})
export class MentorLandingpageComponent implements OnInit {

  @Input() mentor1:Mentor;
  constructor(private route:Router) { }

  ngOnInit() {
  }

  Received(){
    this.route.navigate(['mentorTrainings'])
  }

  profile(){
    this.route.navigate(['mentorProfile'])
  }
  payments(){
    this.route.navigate(['mentorPayments'])
  }
  progress(){
    this.route.navigate(['trainingProgress'])
  }
}
