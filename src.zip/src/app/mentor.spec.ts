import { Mentor } from './mentor';

describe('Mentor', () => {
  it('should create an instance', () => {
    expect(new Mentor()).toBeTruthy();
  });
});
