import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user';
import { Technologies } from './technologies';

@Injectable({
  providedIn: 'root'
})
export class UserService {

 private baseUrl='http://localhost:9085/api1';

  constructor(private http:HttpClient) { }

  createUser(user:User):Observable<User>{
    return this.http.post<User>(`${this.baseUrl}/create`,user);
  }

  getTechnologies(name:string,start_time:string):Observable<any>{
    return this.http.get<Technologies>(`${this.baseUrl}/gettechnology/${name}/${start_time}`);
  }

  getUser(username:string,password:string):Observable<User>{
    return this.http.get<User>(`${this.baseUrl}/checkUser/${username}/${password}`);
  }

  
}
