import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Technologies } from './technologies';


@Injectable({
  providedIn: 'root'
})
export class TrainingsService {
  private baseUrl='http://localhost:9085/api3';
  constructor(private http:HttpClient) { }

}
