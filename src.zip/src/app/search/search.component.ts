import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Technologies } from '../technologies';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
 technologies1:Observable<Technologies[]>;
 technologies:Technologies =new Technologies()
 name:string;
 start_time:string;
  constructor(private userService:UserService) { }

  ngOnInit() {
  }
  
  onSubmit(){
   console.log("inside search submit")
   this.technologies1=this.userService.getTechnologies(this.technologies.name,this.technologies.start_time);
  }
}
