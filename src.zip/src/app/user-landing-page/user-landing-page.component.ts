import { Component, OnInit } from '@angular/core';
import { TechnologiesService } from '../technologies.service';
import { Technologies } from '../technologies';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-landing-page',
  templateUrl: './user-landing-page.component.html',
  styleUrls: ['./user-landing-page.component.css']
})
export class UserLandingPageComponent implements OnInit {

  
  constructor(private technologiesService:TechnologiesService,private route:Router) { }

  ngOnInit() {
  }

  courses(){
    this.route.navigate(['courses'])
  }

  allTrainings(){
    this.route.navigate(['allTrainings'])
  }

  proposedTrainings(){
    this.route.navigate(['proposedTrainings'])
  }

  completedTrainings(){
    this.route.navigate(['completedTrainings'])
  }
}
